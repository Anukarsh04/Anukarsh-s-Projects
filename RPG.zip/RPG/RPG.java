
/**
 * Write a description of class RPG here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RPG
{
    
    public static void main (String args[])

    { 
        new RPG();
    }

    /**
     * Constructor for objects of class RPG
     */
    public RPG()
    {
        
        RPS rpsobject = new RPS();
        blackjack blackjackobject = new blackjack();
       
        
       
    }
}