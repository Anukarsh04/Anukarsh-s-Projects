/**
 * Write a description of class blackjack here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class blackjack
{
    //instance variables to keep track of score
    int playerScore = 0;
    int dealerScore = 0;

    public static void main(String args[]){
        new blackjack ();
    }

    public blackjack(){
        //first two cards the player and dealer are given
        int playerCards = 2;
        int dealerCards = 2;

        //drawing first two cards , add it too the player score,

        int playercard1=  (int) ((Math.random()*9)+2);
        int playercard2=  (int) ((Math.random()*9)+2);
        playerScore= playercard1 + playercard2;

        System.out.println("You got a " + cardName(playercard1) + ".");
        System.out.println("You also got a " + cardName(playercard2) + ".");
        System.out.println("Your score is: " + playerScore);
        System.out.println();

        //player winning test
        if (playerScore == 21) {
            System.out.println("You won!");
        } else {

            //testing score cap as well as exiting loop condition
            char anothercard = IBIO.inputChar("Do you want to pick up another card (max 5 cards)? (y/n) "); // moving towards exiting loop condition
            while ((anothercard == 'y' || anothercard == 'Y') && playerCards < 5 && playerScore <= 21){
                int newcardval =  (int) ((Math.random()*9)+2);
                System.out.println("You picked up a " + cardName(newcardval) + ".");
                playerScore+= newcardval;
                System.out.println("Your current score is " + playerScore + ".");
                if(playerScore==21) {
                    try
                    {
                        Thread.sleep (3000);
                    }
                    catch (InterruptedException m)
                    {
                        ;
                    }
                    System.out.println("You won!");
                }

                playerCards++; //adding cards so they cant go over 5 cards

                if (playerScore > 21) {    
                    //ending game
                    try
                    {
                        Thread.sleep (3000);
                    }
                    catch (InterruptedException m)
                    {
                        ;
                    }
                    System.out.println("\nYour score was over 21. You lost the game ");
                } else if (playerCards == 5) {
                    System.out.println("\n You have  picked up the maximum amount of cards! It's the dealer's turn.\n");// exiting loop
                }
                else{
                    anothercard=IBIO.inputChar("Do you want to pick up another card (max 5 cards)? (y/n) ");
                }
            }  

            if( playerScore<21)
            {
                System.out.println("It's now the dealer's turn.");

                //drawing first two cards , add it too the dealer score,      
                int dealercard1=  (int) ((Math.random()*9)+2);
                int dealercard2=  (int) ((Math.random()*9)+2);
                dealerScore= playercard1 + playercard2;
                System.out.println("The dealer drew a " + cardName(dealercard1) + ".");
                System.out.println("The dealer also drew a " + cardName(dealercard2) + ".");
                System.out.println("The dealer's current score is : " + dealerScore);
                System.out.println();

                //Testing if dealer has won
                if (dealerScore == 21) {
                    try
                    {
                        Thread.sleep (3000);
                    }
                    catch (InterruptedException m)
                    {
                        ;
                    }
                    System.out.println("\nThe dealer won!");
                } else  {

                    //dealers losing and exiting while loop condition
                    while (dealerCards < 5 && dealerScore < 16) {
                        int newcardvalb =  (int) ((Math.random()*9)+1);        
                        System.out.println("The dealer drew a " + cardName(newcardvalb) + ".");
                        dealerScore+= newcardvalb;
                        System.out.println("The dealer's score is now " + dealerScore + ".");
                        System.out.println();

                        dealerCards++; //moving towards maximum 5 cards

                        if (dealerScore > 21) {
                            //ending the game and quitting the program
                            try
                            {
                                Thread.sleep (3000);
                            }
                            catch (InterruptedException m)
                            {
                                ;
                            }
                            System.out.println("\nThe dealer's score was over 21. You win ");
                        } else if (dealerCards == 5) {
                            System.out.println("\nThe dealer picked up the maximum amount of cards.");
                        }

                    }
                    try
                    {
                        Thread.sleep (3000);
                    }
                    catch (InterruptedException m)
                    {
                        ;
                    }
                }
            }

            if (dealerScore<21&&playerScore<21){
                if (playerScore == dealerScore) {
                    System.out.println("\nYou drew with the dealer. Boring!");
                } else if (dealerScore > playerScore) {
                    System.out.println("\nYou have suffered defeat at the hand of the dealer.");
                } else {
                    System.out.println("\nCongratulations! You have beaten the dealer.");
                }

            }
        }
    }

    //assigning names to numerical card values
    public static String cardName(int number){
        String name = "";
        if (number == 2) {
            name = "Two";
        } else if (number == 3) {
            name = "Three";
        } else if (number == 4) {
            name = "Four";
        } else if (number == 5) {
            name = "Five";
        } else if (number == 6) {
            name = "Six";
        } else if (number == 7) {
            name = "Seven";
        } else if (number == 8) {
            name = "Eight";
        } else if (number == 9) {
            name = "Nine";
        } else if (number == 11) {
            name = "Ace";
        } else  {
            int facecard = (int) ((Math.random()*3)+1);
            if (facecard == 1) {
                name = "Jack";
            } else if (facecard == 2) {
                name = "Queen";
            } else {
                name = "King";
            }   
        }
        return name;

    
    }
}
