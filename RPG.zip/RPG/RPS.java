 


/**
 * Write a description of class RPS here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RPS
{
    int playerScore = 0;
    int opponentScore = 0;
    int oppnum = 'o';
    char oppweapon = 'o';
    char playerweapon = 'o';

    public static void main (String args[])
    {
        new RPS();
    }

    /**
     * Constructor for objects of class RPS
     */
    public RPS()
    {
        instructions();

        repeat();
    }

    public void instructions()
    {
        System.out.println(" Welcome to BOOM POW BLAST");
        System.out.println(" The instructions are simple");
        System.out.println(" You choose one of three weapons, \n Galactus,  Trident or Zapatron");
        System.out.println(" Trident beats Galactus \n Zapatron beats Trident \n And Galactus beats Zapatron");
        System.out.println(" Each win equals one point");
        System.out.println(" First to three points wins ");
    }

    public void repeat()
    {
        if(playerScore == 3) {
            System.out.println(" Congratulations! You have won the whole game");
        }
        else if ( opponentScore == 3) {
            throw new RuntimeException(" Unlucky! You have lost the whole game");
        }

        char continu = 'y';
        while( continu == 'y' && playerScore<3 && opponentScore<3)
        {
            playerweapon = IBIO.inputChar(" What weapon do you want, Galactus(g), Trident (t) or Zapatron(z)?");
            {
                continu = cont(playerweapon);
                if( continu == 'n') {
                    System.out.println(" You picked the " + wepname(playerweapon));

                }
                else {
                    System.out.println(" Error :( \n  You picked an invalid option \n Try again!");

                }
                while ( continu == 'n')
                {
                    oppnum = number();
                    oppweapon = name(oppnum);

                    System.out.println(" Your opponent picked the " + wepname(oppweapon));
                    continu = 'y';
                    decision();
                }

            }
        }
    }

    public void decision()
    {

        try{
            Thread.sleep(2500);
        }
        catch (InterruptedException m){

        }
        if( playerweapon == oppweapon) {
            System.out.println("You and your opponent both picked " + wepname(playerweapon));
            System.out.println("Try again");
            repeat();
        }
        else if ( playerweapon == 'g')
        {
            if( oppweapon == 't') {
                System.out.println( wepname(oppweapon) + " beats " + wepname(playerweapon) + ". You lost the round :(");
                opponentScore ++;
                System.out.println(" You: " + playerScore + "         Opponent: " + opponentScore);
                repeat();
            }
            else  {
                System.out.println( wepname(playerweapon) + " beats " + wepname(oppweapon) + ". You won the round :)");
                playerScore ++;
                System.out.println(" You: " + playerScore + "         Opponent: " + opponentScore);
                repeat();
            }
        }
        else if ( playerweapon == 't') 
        {
            if( oppweapon == 'z') {
                System.out.println( wepname(oppweapon) + " beats " + wepname(playerweapon) + ". You lost the round :(");
                opponentScore ++;
                System.out.println(" You: " + playerScore + "         Opponent: " + opponentScore);
                repeat();
            }
            else {
                System.out.println( wepname(playerweapon) + " beats " + wepname(oppweapon) + ". You won the round :)");
                playerScore ++;
                System.out.println(" You: " + playerScore + "         Opponent: " + opponentScore);
                repeat();
            }
        }
        else {
            if( oppweapon == 'g') {
                System.out.println( wepname(oppweapon) + " beats " + wepname(playerweapon) + ". You lost the round :(");
                opponentScore ++;
                System.out.println(" You: " + playerScore + "         Opponent: " + opponentScore);
                repeat();
            }
            else {
                System.out.println( wepname(playerweapon) + " beats " + wepname(oppweapon)+ ". You won the round :)");
                playerScore ++;
                System.out.println(" You: " + playerScore + "         Opponent: " + opponentScore);
                repeat();

            }
        }
    }

    public int number ()
    {
        int number = (int)((Math.random()*3)+1);
        return number;
    }

    public char name (int number)
    {
        char name = 'o';
        if( number == 1)
        {
            name = 'g';
        }
        else if( number == 2) 
        {
            name = 't';
        }
        else
        {
            name = 'z';
        }
        return name;
    }

    public String wepname (char i)
    {
        String wep = "";
        if ( i == 'g') {
            wep = "Galactus";
        }
        else if ( i == 't') {
            wep = "Trident";
        }
        else {
            wep = "Zapatron";
        }

        return wep;
    }

    public char cont (char j)
    {
        char x = 'o';
        if ( j == 'g') {
            x = 'n';
        }
        else if ( j == 't') {
            x = 'n';
        }
        else if ( j == 'z') {
            x = 'n';
        }
        else {
            x = 'y';
        }

        return x;
    }
}

