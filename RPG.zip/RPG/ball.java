
/**
 * Write a description of class ball here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ball
{
    public static void main (String args[])
    {
        new ball ();
    }

    /**
     * Constructor for objects of class ball
     */
    public ball()
    {
        System.out.println("Magic 8 ball");
      /* outlook not so good
       * don't count on it
       * my sources say no
       * without a doubt
       * reply hazy, try again
       * it is certain
       * my reply is no
       * as i see it yes
       * most likely
       * you may rely on it
       * cannot predict now
       * outlook good
       * better not tell you now
       * very doubtful
       * yes definitely
       * concentrate and ask again
       */
       IBIO.inputString("What is your question: ");
       int num = (int) (Math.random () *13) +1;
       if (num == 1)
       System.out.println("outlook not so good");
       else if (num == 2)
       System.out.println("don't count on it");
       else if (num == 3)
        System.out.println("my sources say no");
       else if (num ==4)
       System.out.println("without a doubt");
       else if (num == 5)
       System.out.println("reply hazy, ");
       else if (num == 6)
       System.out.println("it is certain");
       else if (num == 7)
       System.out.println("my reply is no");
       else if (num ==8)
       
       System.out.println("as i see it yes");
       else if (num==9)
       System.out.println("cannot predict now");
       else if (num==10)
       System.out.println("outlook good");
       else if (num==11)
       System.out.println("better not tell you now");
       else if (num==12)
       System.out.println("very doubtful");
       else {
       System.out.println("yes definitely");
    }
      
       if (num == 4 || num == 6 || num == 8 || num == 10 || num == 13)
       {
       
}
}
}
    

    